
function OnPlayerSpawned()  
local player_entity_id = (EntityGetWithTag("player_unit") or {})[1]
 EntitySetTransform(player_entity_id, 910, -5)
end

        